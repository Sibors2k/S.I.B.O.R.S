# src/modules/ventas/ventas_controller.py

from typing import List, Dict, Optional
from sqlalchemy.orm import Session, joinedload
from datetime import datetime, timezone

from .ventas_model import Venta, VentaDetalle, VentaPago, EstadoVenta, MetodoPago
from modules.productos.producto_controller import ProductoController
from modules.contabilidad.contabilidad_controller import ContabilidadController
from modules.clientes.cliente_controller import ClienteController
from modules.contabilidad.contabilidad_model import TipoMovimiento
from modules.productos.models import Producto, TipoAjusteStock, ProductoPlantilla, KitComponente

class VentasController:
    def __init__(self, db_session: Session, producto_ctrl: ProductoController, contabilidad_ctrl: ContabilidadController, cliente_ctrl: ClienteController):
        self.db = db_session
        self.producto_ctrl = producto_ctrl
        self.contabilidad_ctrl = contabilidad_ctrl
        self.cliente_ctrl = cliente_ctrl
        self.transaccion_actual: Optional[Venta] = self.obtener_venta_en_progreso()

    def iniciar_nueva_venta(self, usuario_id: int, cliente_id: Optional[int] = None) -> Venta:
        if self.transaccion_actual:
            self.cancelar_venta_actual()
        nueva_venta = Venta(usuario_id=usuario_id, cliente_id=cliente_id, estado=EstadoVenta.EN_PROGRESO)
        self.db.add(nueva_venta)
        self.db.commit()
        self.db.refresh(nueva_venta)
        self.transaccion_actual = nueva_venta
        return self.transaccion_actual

    def agregar_producto_al_carrito(self, producto_id: int, cantidad: int) -> Venta:
        if not self.transaccion_actual:
            raise ValueError("No hay una venta activa. Inicia una nueva venta primero.")
        if cantidad <= 0:
            raise ValueError("La cantidad debe ser un número positivo.")
        producto = self.db.get(Producto, producto_id)
        if not producto:
            raise ValueError("El producto no existe.")
        detalle_existente = self.db.query(VentaDetalle).filter_by(venta_id=self.transaccion_actual.id, producto_id=producto_id).first()
        if detalle_existente:
            detalle_existente.cantidad += cantidad
        else:
            nuevo_detalle = VentaDetalle(
                venta_id=self.transaccion_actual.id,
                producto_id=producto.id,
                cantidad=cantidad,
                precio_unitario=producto.precio_venta
            )
            self.db.add(nuevo_detalle)
        self._recalcular_totales_venta()
        self.db.commit()
        self.db.refresh(self.transaccion_actual)
        return self.transaccion_actual

    def eliminar_detalle_del_carrito(self, detalle_id: int) -> Optional[Venta]:
        if not self.transaccion_actual:
            raise ValueError("No hay una venta activa.")
        detalle_a_eliminar = self.db.get(VentaDetalle, detalle_id)
        if detalle_a_eliminar and detalle_a_eliminar.venta_id == self.transaccion_actual.id:
            self.db.delete(detalle_a_eliminar)
            self._recalcular_totales_venta()
            self.db.commit()
            if not self.transaccion_actual.detalles:
                self.cancelar_venta_actual()
                return None
            self.db.refresh(self.transaccion_actual)
            return self.transaccion_actual
        else:
            raise ValueError("El detalle del producto no se encontró en la venta actual.")
            
    def _recalcular_totales_venta(self):
        if not self.transaccion_actual: return
        subtotal_general = 0
        for detalle in self.transaccion_actual.detalles:
            detalle.subtotal_linea = detalle.precio_unitario * detalle.cantidad
            subtotal_general += detalle.subtotal_linea
        self.transaccion_actual.subtotal = subtotal_general
        self.transaccion_actual.total = subtotal_general - self.transaccion_actual.descuento_total + self.transaccion_actual.impuestos

    def finalizar_venta(self, pagos: List[Dict], usuario_id: int) -> Venta:
        # La lógica de finalizar venta no cambia, pero es importante que ya no devuelva nada.
        # ... (código sin cambios)
        pass

    def cancelar_venta_actual(self):
        if self.transaccion_actual:
            venta_a_cancelar = self.transaccion_actual
            self.transaccion_actual = None
            self.db.delete(venta_a_cancelar)
            self.db.commit()

    def obtener_venta_en_progreso(self) -> Optional[Venta]:
        return self.db.query(Venta).options(
            joinedload(Venta.detalles).joinedload(VentaDetalle.producto).joinedload(Producto.plantilla)
        ).filter_by(estado=EstadoVenta.EN_PROGRESO).first()

    def listar_ventas_completadas(self) -> List[Venta]:
        return self.db.query(Venta).filter_by(estado=EstadoVenta.COMPLETADA).options(
            joinedload(Venta.detalles).joinedload(VentaDetalle.producto).joinedload(Producto.plantilla),
            joinedload(Venta.cliente),
            joinedload(Venta.usuario)
        ).order_by(Venta.fecha.desc()).all()